#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#run using 3 argv, algn glob 2à2  :  $python3 run.py ../data/seq1 ../data/seq2
#to Sharleen S. , thank you for the 4 am pancakes

import sq,mat,tbk
sq.sq()
mat.mat()
tbk.tbk()
print("\n-----DONE-----")