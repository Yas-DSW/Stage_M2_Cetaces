########2 sequences fasta#########
import sys, re
from Bio.Seq import Seq
def sq():
	seqa=seqb=""
	with open (sys.argv[1]) as fd1 :
		for line in fd1 :
			regex1=re.search("(^[^> | ^;].*[^\n])",line) #if fasta
			if regex1: seqa+=regex1.group(1)
	with open (sys.argv[2]) as fd2 :
		for line in fd2 :
			regex2=re.search("(^[^> | ^;].*[^\n])",line) #if fasta
			if regex2:seqb+=regex2.group(1)
	global seqn
	seqn= Seq(seqa) 
	global seqm
	seqm= Seq(seqb) 
