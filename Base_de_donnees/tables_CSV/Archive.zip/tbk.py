###########traceback#############
from Bio.Seq import Seq
import sq
import mat
def tbk():
	a=len(sq.seqn)-1
	b=len(sq.seqm)-1
	i=mat.m
	j=mat.n
	con=0#match
	pen=-3 #gap=indel=g
	#need to add score of mismatch
	
	seqn2= seqm2= alg=Seq("")

	while (i>=1 or j>=1): 
		if(sq.seqn[a]==sq.seqm[b] and mat.mat[i,j]==mat.mat[i-1,j-1]+con) :
			seqn2=seqn2+(sq.seqn[a])
			seqm2=seqm2+(sq.seqm[b])
			a=a-1
			b=b-1
			i=i-1
			j=j-1
		#gap &vert
		elif (mat.mat[i,j]==mat.mat[i-1,j]+pen) :	
			seqn2=seqn2+("-")
			seqm2=seqm2+(sq.seqm[b])
			b=b-1
			i=i-1
		#gap & horz
		elif(mat.mat[i,j]==mat.mat[i,j-1]+pen) :
			seqn2=seqn2+(sq.seqn[a])
			seqm2=seqm2+("-")
			a=a-1	
			j=j-1
		else :#subs
			seqn2=seqn2+(sq.seqn[a])
			seqm2=seqm2+(sq.seqm[b])
			a=a-1
			b=b-1
			i=i-1
			j=j-1

	#found on github:
	rev_seqn2=seqn2[::-1]
	rev_seqm2=seqm2[::-1]
	for i in range(0,len(rev_seqn2)):
		if rev_seqn2[i]==rev_seqm2[i]:alg=alg+("|")
		else : alg=alg+(" ")
	print('\n',rev_seqn2,'\n',alg,'\n',rev_seqm2)

