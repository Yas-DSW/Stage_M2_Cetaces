###########matrix############
import numpy
import sq
def mat():
	global n
	n=len(sq.seqn)
	global m
	m=len(sq.seqm)
	global mat
	mat=numpy.zeros((m+1,n+1)) #using numpy

	#initialization
	mat[0,0]=0
	con=0#match
	pen=-3 #gap=indel=g
	#need to add score of mismatch
	
	for i in range (1,m+1) :mat[i,0]=mat[i-1,0]+pen
	for j in range(1, n+1) :mat[0,j]=mat[0,j-1]+pen

	#fill in
	for j in range(1,n+1) :
		for i in range (1,m+1) :
			if (sq.seqn[j-1]==sq.seqm[i-1]):mat[i,j]=mat[i-1,j-1]+con #identity
			else : #indel 
				diag=(mat[i-1,j-1]+pen)
				horz=(mat[i-1,j]+pen)
				vert=(mat[i,j-1]+pen)
				if (diag>=horz and diag>=vert):mat[i,j]=diag
				elif (horz>= diag and horz>=vert):mat[i,j]=horz
				else:mat[i,j]=vert
	print("\nscore = "+str(mat[m,n]))
